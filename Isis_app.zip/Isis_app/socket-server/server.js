const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());

const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: '*', // em produção, restrinja para o domínio do seu app
    methods: ['GET', 'POST'],
  },
});

io.on('connection', (socket) => {
  console.log('Cliente conectado:', socket.id);

  // Escutando um evento vindo do cliente
  socket.on('sendMessage', (data) => {
    console.log('Mensagem recebida:', data);

    // Reenvia para todos os clientes conectados
    io.emit('receiveMessage', data);
  });

  // Exemplo de entrar em uma "sala" (room)
  socket.on('joinRoom', (room) => {
    socket.join(room);
    console.log(`Socket ${socket.id} entrou na sala ${room}`);
  });

  socket.on('disconnect', () => {
    console.log('Cliente desconectado:', socket.id);
  });
});

const PORT = 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});