import { Tabs, router } from 'expo-router'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import MaterialDesignIcons from '@react-native-vector-icons/material-design-icons'
import Octicons from '@react-native-vector-icons/octicons'

import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'

export default function TabsLayout() {
  const insets = useSafeAreaInsets()


  return (
    <>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarShowLabel: false,
          tabBarActiveTintColor: Cores.primariaEscura,
          tabBarInactiveTintColor: Cores.secundariaEscura,
          tabBarStyle: {
            backgroundColor: Cores.fundo,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 8,
        },
        shadowOpacity: 0.8,
        shadowRadius: 15,
      paddingBottom: insets.bottom || 16,
      height: 60 + (insets.bottom || 0),
      borderTopWidth: 0,
      paddingTop: 10,
            }
        }} 
      >
      <Tabs.Screen
        name='home'
        options={{
          tabBarIcon: ({ color }) => (
            <Octicons name='home' size={Fontes.grande2} color={color} />
          )
        }}
      />
<Tabs.Screen
        name='botaoPanico'
        options={{
          tabBarIcon: ({ color }) => (
            <MaterialDesignIcons name="alarm-light" size={Fontes.grande2} color={color} />
          )
        }}
      />
      <Tabs.Screen
        name='diarioDigital'
        options={{
          tabBarIcon: ({ color }) => (
            <Octicons name='book' size={Fontes.grande2} color={color} />
          )
        }}
      />
      <Tabs.Screen
        name='chatConversa'
        options={{
          tabBarIcon: ({ color }) => (
            <Octicons name='comment-discussion' size={Fontes.grande2} color={color} />
          )
        }}
      />
      <Tabs.Screen
        name='redesApoio'
        options={{
          tabBarIcon: ({ color }) => (
            <Octicons  name='location' size={Fontes.grande2} color={color} />
          )
        }}
      />
      <Tabs.Screen
  name='(pilha)'
  options={{
    href: null,
  }}
/>
    </Tabs>
    </>
    )
}
