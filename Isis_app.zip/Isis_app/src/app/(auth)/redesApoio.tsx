import { Cabecalho } from '@/components/Cabecalho'
import { StyleSheet, Image, View, Pressable, Text } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import MapView from 'react-native-maps'
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'

export default function RedesApoio() {
    return (
        <SafeAreaView style={estilos.conteinerGlobal}>
            <Cabecalho />
            <View style={estilos.conteiner}>

                <Pressable style={estilos.barraPesquisa}>
                    <Image
                        style={estilos.icone}
                        source={require('@/assets/icones/lupa.png')}
                    />
                    <Text style={estilos.texto}> Pesquisar redes de apoio ou endereços </Text>
                </Pressable>
                <View style={{flex:1, justifyContent: 'center', alignItems: 'center'}}>
                    <MapView
                        style={estilos.mapa}
                        initialRegion={{
                            latitude: -22.9500208,
                            longitude: -43.193795,
                            latitudeDelta: 0.0922,
                            longitudeDelta: 0.0421
                        }}
                    >
                    </MapView>
                </View>
            </View>
        </SafeAreaView >
    )
}

const estilos = StyleSheet.create({
    conteinerGlobal: {
        backgroundColor: Cores.primariaClara,
        flex: 1,
    },

    conteiner: {
        flexDirection: 'column',
    },
    mapa: {
        width: '80%',
        height: '100%',
    },

    barraPesquisa: {
        position: 'absolute',
        top: 16,
        left: 16,
        right: 16,
        zIndex: 10,
        backgroundColor: Cores.fundo,
        borderRadius: 20,
        flexDirection: 'row',
        gap: 10,
        padding: 12,
        alignItems: 'center',
        elevation: 4,
    },

    imagem: {

        flex: 1,
    },
    icone: {
        width: 25,
        height: 25,
    },
    texto: {
        flex: 1,
        fontSize: Fontes.medio1,
        color: Cores.subtitulo,
    },
})
