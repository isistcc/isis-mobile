import { Text, StyleSheet, TextInput, Pressable, Alert, Image, View, ScrollView} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Cabecalho } from '@/components/Cabecalho'
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'
import { router } from 'expo-router'

export default function BotaoPanico() {

    return (
        <SafeAreaView style={estilos.conteinerGlobal}>
                <Cabecalho />
            <ScrollView>
                <View style={estilos.conteiner}>
                    <Pressable
                        onPress={() => router.push('/home')}>
                        <Text style={estilos.subTitulo}>‹ Voltar</Text>
                    </Pressable>
                    <Text style={estilos.titulo}>Botão de pânico</Text>
                    <Text style={estilos.subTitulo}>Precisa de ajuda agora? Acione o botão abaixo e sua localização será enviada para contatos e serviços de emergência.</Text>
                    <View style={estilos.coluna}>
                        <Pressable>
                            <Image
                                style={estilos.imagem}
                                source={require('@/assets/images/acionar.png')}
                            />
                        </Pressable>
                        <View style={estilos.campo}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/escudo3.png')}
                            />
                            <View style={estilos.conteinerTexto}>
                                <Text style={estilos.tituloCampo}>Sua segurança é nossa prioridade</Text>
                                <Text style={estilos.subTitulo}>Ao acionar o botão seus contatos de confiança e serviços de emergência serão notificados.</Text>
                            </View>
                        </View>



                        <View style={estilos.campoBranco}>
                            <Text style={estilos.tituloCampo}>Outras formas de pedir ajuda</Text>
                            <View style={estilos.campo}>
                                <Image
                                    style={estilos.icone}
                                    source={require('@/assets/icones/telefone.png')}
                                />
                                <View>
                                    <Text style={estilos.tituloCampo}>Ligar para o 180</Text>
                                    <Text style={estilos.subTitulo}>Central de Atendimento à Mulher.</Text>
                                </View>
                            </View>
                            <View style={estilos.campo}>
                                <Image
                                    style={estilos.icone}
                                    source={require('@/assets/icones/info.png')}
                                />
                                <Text style={estilos.subTitulo}>O 180 funciona 24h por dia, todos os dias. A ligação é gratuita e sigilosa.</Text>
                            </View>
                        </View>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

const estilos = StyleSheet.create({
    conteinerGlobal: {
        backgroundColor: Cores.fundo,
    },
    conteiner: {
        padding: 20,
        flex: 1,
        flexDirection: 'column',
        backgroundColor: Cores.primariaClara,
    },

    conteinerTexto: {
        flex: 1,
        width: '40%',
    },

    coluna: {
        alignItems: 'center',
    },

    titulo: {
        fontSize: Fontes.grande1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        paddingVertical: 6,
        lineHeight: Fontes.grande1 * 1.2,
    },
    tituloCampo: {
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
    },
    subTitulo: {
        flex: 1,
        fontSize: Fontes.medio2,
        color: Cores.subtitulo,
        marginBottom: 14,
        lineHeight: 20,
    },


    rotulo: {
        fontSize: Fontes.medio1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        textAlign: 'center',
    },

    lerMais: {
        fontSize: Fontes.pequeno,
        fontFamily: Fontes.baseBold,
        color: Cores.primariaEscura,
    },

    imagem: {
        width: 300,
        height: 300,
    },

    icone: {
        width: 35,
        height: 35,
    },
    campo: {
        padding: 10,
        gap: 10,
        borderRadius: 15,
        marginBottom: 10,
        borderWidth: 1,
        flexDirection: 'row',
        alignItems: 'center',
        fontSize: Fontes.pequeno,
        borderColor: Cores.primaria,
        backgroundColor: Cores.primariaClara,
    },
    campoBranco: {
        padding: 10,
        borderRadius: 15,
        marginBottom: 10,
        fontSize: Fontes.pequeno,
        backgroundColor: Cores.fundo,
    },
})
