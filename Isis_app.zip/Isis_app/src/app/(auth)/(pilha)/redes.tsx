import { Text, StyleSheet, TextInput, Pressable, Alert, Image, View, ScrollView } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Cabecalho } from '@/components/Cabecalho'
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'
import { router } from 'expo-router'

export default function Redes() {

    return (
        <SafeAreaView style={estilos.conteinerGlobal}>
            <Cabecalho />
            <ScrollView style={estilos.conteiner}>
                <Pressable
                    onPress={() => router.push('/diarioDigital')}>
                    <Text style={estilos.subTitulo}>‹ Voltar</Text>
                </Pressable>

                <View style={estilos.cartaoPrincipal}>
                    <View style={estilos.conteinerIcone}>
                        <Image
                            style={estilos.icone}
                            source={require('@/assets/icones/livro.png')}
                        />
                    </View>
                    <View style={estilos.conteinerTexto}>
                        <Text style={estilos.titulo}>Rede de apoio</Text>
                        <Text style={estilos.subTitulo}>Construa e fortaleça sua rede de apoio com pessoas que te acolhem e te fazem bem.</Text>
                    </View>
                </View>
                <View style={estilos.coluna}>
                    <View style={estilos.campo}>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Sobre essa etapa</Text>
                            <Text style={estilos.texto}>Você não precisa enfrentar tudo sozinha. Ter com quem contar faz toda a diferença na sua jornada. Identifique, aproxime-se e fortaleça sua rede de apoio.</Text>
                        </View>
                    </View>
                </View>


                <Text style={estilos.tituloCampo}>Atividades</Text>

                <View style={estilos.coluna}>
                    <Pressable style={estilos.campo}>
                        <View style={estilos.conteinerIconeRosa}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/balanca.png')}
                            />
                        </View>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Identifique quem te apoia</Text>
                            <Text style={estilos.texto}>Pense nas pessoas que já demonstraram cuidado e que você confia.</Text>
                        </View>
                    </Pressable>

                    <Pressable style={estilos.campo}>
                        <View style={estilos.conteinerIconeRoxo}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/aviso.png')}
                            />
                        </View>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Fortaleça seus vínculos</Text>
                            <Text style={estilos.texto}>Unvista tempo de qualidade com as pessoas que te fazem bem.</Text>
                        </View>
                    </Pressable>


                    <Pressable style={estilos.campo}>
                        <View style={estilos.conteinerIconeRosa}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/maos.png')}
                            />
                        </View>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Peça ajuda quando precisar</Text>
                            <Text style={estilos.texto}>Não tenha medo de pedir ajuda. Você merece e tem direito de ser apoiada.</Text>
                        </View>
                    </Pressable>

                    <Pressable style={estilos.campo}>
                        <View style={estilos.conteinerIconeRoxo}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/casaLoc.png')}
                            />
                        </View>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Participe de grupos e comunidades</Text>
                            <Text style={estilos.texto}>Conecte-se com grupos que compartilham interesses ou expereiências semelhantes.</Text>
                        </View>
                    </Pressable>

                    <Pressable style={estilos.campo}>
                        <View style={estilos.conteinerIconeRosa}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/maos.png')}
                            />
                        </View>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Ofereça apoio também</Text>
                            <Text style={estilos.texto}>Ajudar outras pessoas também fortalece sua rede e seu bem -estar.</Text>
                        </View>
                    </Pressable>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

const estilos = StyleSheet.create({

    conteinerGlobal: {
        flex: 1,
        backgroundColor: Cores.primariaClara,
        flexDirection: 'column'
    },

    conteiner: {
        padding: 20,
    },

    cartaoPrincipal: {
        flexDirection: 'row',
        width: '100%',
        maxWidth: 350,
        alignItems: 'center',
        backgroundColor: Cores.primariaClara,
        borderRadius: 15,
        gap: 16,
        padding: 20,
    },

    conteinerIcone: {
        width: 60,
        height: 60,
        backgroundColor: Cores.secundariaClara,
        borderRadius: 15,
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.4,
        shadowRadius: 10,
        elevation: 3,
    },
    conteinerIconeRosa: {
        width: 44,
        height: 44,
        backgroundColor: Cores.primariaClara,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
    },

    conteinerIconeRoxo: {
        width: 44,
        height: 44,
        backgroundColor: Cores.secundariaClara,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
    },

    conteinerTexto: {
        flex: 1,
        flexShrink: 1,
        minWidth: 0,
    },
    coluna: {
        alignItems: 'center',
    },

    titulo: {
        fontSize: Fontes.grande1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        paddingVertical: 6,
    },
    tituloCampo: {
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
    },
    subTitulo: {
        fontSize: Fontes.medio2,
        color: Cores.subtitulo,
    },

    texto: {
        flex: 1,
        fontSize: Fontes.medio1,
        color: Cores.subtitulo,
    },
    rotulo: {
        fontSize: Fontes.medio1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        textAlign: 'center',
    },

    lerMais: {
        fontSize: Fontes.pequeno,
        fontFamily: Fontes.baseBold,
        color: Cores.primariaEscura,
    },

    imagem: {
        width: 300,
        height: 300,
    },

    icone: {
        width: 30,
        height: 30,
    },
    campo: {
        padding: 10,
        gap: 10,
        width: '100%',
        maxWidth: 350,
        borderRadius: 15,
        marginBottom: 10,
        borderWidth: 1,
        flexDirection: 'row',
        alignItems: 'center',
        fontSize: Fontes.pequeno,
        borderColor: Cores.primaria,
        backgroundColor: Cores.fundo,
    },
})