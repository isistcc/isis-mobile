import { useState } from 'react';
import { Cabecalho } from '@/components/Cabecalho'
import { Text, StyleSheet, Pressable, Image, View } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Acordeao } from '@/components/Acordeao'
import { router } from 'expo-router'
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'


function Conteudo({ titulo, children }: { titulo: string; children: string }) {
    return (
        <View>
            <Text style={estilos.tituloCampo}>{titulo}</Text>
            <Text style={estilos.texto}>{children}</Text>
        </View>
    )
}

export default function Informacoes() {
    const [abertoId, setAbertoId] = useState<string | null>(null)

    const toggleAccordion = (id: string) => {
        setAbertoId(abertoId === id ? null : id)
    }

    return (
        <SafeAreaView style={estilos.conteinerGlobal}>
            <Cabecalho />
            <View style={estilos.conteiner}>
                <Pressable
                    onPress={() => router.push('/home')}>
                    <Text style={estilos.subTitulo}>‹ Voltar</Text>
                </Pressable>
                <View style={estilos.conteinerTexto}>
                    <Text style={estilos.titulo}>Informações que protegem</Text>
                    <Text style={estilos.subTitulo}>Aprenda a reconhecer sinais de violência e descubra os recursos disponíveis para sua proteção.</Text>
                </View>

                <Acordeao
                    id="tiposViolencia"
                    titulo="Tipos de violência"
                    aberto={abertoId === 'tiposViolencia'}
                    onToggle={toggleAccordion}
                >
                    <Conteudo titulo="Física:">
                        Qualquer conduta que ofenda a integridade corporal da vítima, como tapas, chutes,
                        empurrões, espancamentos e estrangulamento.
                    </Conteudo>
                    <Conteudo titulo="Psicológica:">
                        Ações que causam dano emocional, isolamento, manipulação, ameaças, controle
                        excessivo, chantagem ou humilhação que prejudiquem a autoestima.
                    </Conteudo>
                    <Conteudo titulo="Sexual:">
                        Qualquer ato sexual não consentido obtido por meio de força, coerção, ou quando a
                        mulher é forçada a realizar ou presenciar atos indesejados (inclusive impedimento
                        ao uso de contraceptivos).
                    </Conteudo>
                    <Conteudo titulo="Patrimonial:">
                        Retenção, destruição, subtração ou controle de bens, recursos econômicos,
                        instrumentos de trabalho ou documentos pessoais da vítima.
                    </Conteudo>
                    <Conteudo titulo="Moral:">
                        Qualquer conduta que configure calúnia, difamação ou injúria, como ofender a
                        honra, espalhar boatos ou xingar a mulher.
                    </Conteudo>
                </Acordeao>

                <Acordeao
                    id="comoSaber"
                    titulo="Como saber se estou em uma situação de violência?"
                    aberto={abertoId === 'comoSaber'}
                    onToggle={toggleAccordion}
                >
                    <Conteudo>
                        ● A pessoa a deixa com medo? Você teme que ela a agrida ou agrida seus
                        filhos? Ela se desculpa e diz que não fará mais? {'\n'}
                        ● A xinga, diminui ou coloca para baixo A isola de amigos e família, proíbe de
                        ter vida social, trabalhar ou estudar? A faz sentir-se culpada ou errada? Mexe
                        no seu celular e redes sociais? {'\n'}
                        ● Rasga suas roupas? Controla suas contas, dinheiro e cartões? Esconde seus
                        bens e documentos? Pega suas coisas sem autorização? Já quebrou suas
                        coisas de propósito? {'\n'}
                        ● Briga com você, a deprecia publicamente, a chama de louca? A acusou de
                        traição? Espalha mentiras para que você seja mal vista? {'\n'}
                        ● A impede de usar anticoncepcional?Já a forçou a fazer sexo sem a sua
                        vontade ou permissão? A obriga a assistir pornografia? A induz ou força a
                        avender seu corpo ou a fazer sexo com outras pessoas? A forçou a abortar
                        ou a engravidar? Já a obrigaram a se casar sem a sua vontade? {'\n'}
                        Se você respondeu sim a algumas dessas perguntas, você está em situação de
                        violência. Afinal, a violência não é só física e pode acontecer de muitas formas.
                    </Conteudo>
                </Acordeao>

                <Acordeao
                    id="seVoceSofre"
                    titulo="Se você sofre violência:"
                    aberto={abertoId === 'seVoceSofre'}
                    onToggle={toggleAccordion}
                >
                    <Conteudo titulo='A culpa não é sua!'>
                        Procure sua rede de apoio, como amigos e familiares que a acolham e cuidem
                        sempre que precisar.
                    </Conteudo>
                    <Conteudo titulo='Procure ajuda especializada!'>
                        Conheça os órgãos públicos de atendimento às mulheres em situação de violência,
                        serviços de assistência e apoio de organizações da sociedade civil e aplicativos
                        preparados para ajudá-la a sair do ciclo de violência.
                    </Conteudo>
                    <Conteudo titulo='Você também pode usar o serviço 180!'>
                        O atendimento às mulheres funciona 24h por dia e oferece informações sore o que
                        fazer, onde ir e como denunciar uma violência.
                    </Conteudo>
                    <Conteudo titulo='Denuncie quando se sentir preparada!'>
                        Vá até a delegacia da mulher ou à delegacia mais esperto da sua casa e, sempre
                        que possível, vá acompanhada.
                    </Conteudo>
                </Acordeao>

                <Acordeao
                    id="sofriViolencia"
                    titulo="Sofri violência. O que eu faço?"
                    aberto={abertoId === 'sofriViolencia'}
                    onToggle={toggleAccordion}
                >
                    <Conteudo titulo='Sofri violência moral ou psicológica. O que eu faço?'>
                        1. Procure ajuda especializada: Existem serviços públicos e organizações
                        sociais que oferecem apoio psicológico.  {'\n'}
                        2. Junte provas: Quanto mais provas conseguir juntar, melhor. Podem ser
                        laudos médicos e/ou psicológicos, depoimentos de amigas(os), familiares ou
                        colegas de trabalho. {'\n'}
                        3. Faça um boletim de ocorrência: Denunciar não é uma decisão fácil e é
                        fundamental que você esteja preparada para os próximos passos. Vá até a
                        delegacia da mulher mais próxima e, sempre que possível, vá acompanhada
                        de um(a) advogado(a) ou defensor(a) público(a). {'\n'}
                    </Conteudo>
                </Acordeao>



            </View>
        </SafeAreaView >
    )
}

const estilos = StyleSheet.create({
    conteinerGlobal: {
        flex: 1,
        backgroundColor: Cores.primariaClara,
    },
    conteiner: {
        padding: 20,
        flexDirection: 'column',
    },
    titulo: {
        fontSize: Fontes.grande1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        paddingVertical: 6,
        lineHeight: Fontes.grande1 * 1.2,
    },
    tituloCampo: {
        fontSize: Fontes.medio1,
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
    },
    subTitulo: {
        flex: 1,
        fontSize: Fontes.medio2,
        color: Cores.subtitulo,
    },
    conteinerTexto: {
        flex: 1,
        width: '65%',
    },
    texto: {
        flex: 1,
        fontSize: Fontes.medio1,
        color: Cores.subtitulo,
    },
})
