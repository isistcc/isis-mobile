import { useState } from 'react'
import { router, Link, Color } from 'expo-router'
import { Text, StyleSheet, TextInput, Pressable, Alert, Image, View, ScrollView } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'
import { Cabecalho } from '@/components/Cabecalho'

export default function Conta() {
    return (
        <SafeAreaView style={estilos.conteinerGlobal}>
            <Cabecalho />
            <ScrollView>
                <View style={estilos.conteiner}>
                    <Pressable
                        onPress={() => router.push('/(tabs)/(pilha)/perfil')}>
                        <Text style={estilos.subTitulo}>‹ Voltar</Text>
                    </Pressable>


                    <Text style={estilos.titulo}>Minha conta</Text>

                    <View style={estilos.conteinerImagem}>
                        <Image
                            style={estilos.imagem}
                            source={require('@/assets/images/logo.png')}
                        />
                    </View>

                    <View>
                        <Text style={estilos.tituloCampo}>Nome completo</Text>
                        <View style={estilos.campo}>
                            <Image
                                style={estilos.icones}
                                source={require('@/assets/icones/usuario.png')}
                            />
                            <Text style={estilos.texto}>Fulana de Tal</Text>
                        </View>
                    </View>

                    <View>
                        <Text style={estilos.tituloCampo}>E-mail</Text>
                        <View style={estilos.campo}>
                            <Image
                                style={estilos.icones}
                                source={require('@/assets/icones/envelope.png')}
                            />
                            <Text style={estilos.texto}>fulanadetal@gmail.com</Text>
                        </View>
                    </View>


                    <View>
                        <Text style={estilos.tituloCampo}>Data de nascimento</Text>
                        <View style={estilos.campo}>
                            <Image
                                style={estilos.icones}
                                source={require('@/assets/icones/calendario.png')}
                            />
                            <Text style={estilos.texto}>dd/mm/aaaa</Text>
                        </View>
                    </View>
                    <Pressable style={estilos.botaoRosa}>
                        <Image
                            style={{
                                width: 15,
                                height: 15,
                            }}
                            source={require('@/assets/icones/lapis.png')} />
                        <Text style={{
                            fontSize: Fontes.medio1,
                            fontFamily: Fontes.baseBold,
                            color: Cores.fundo,
                        }}
                        >Salvar registro</Text>
                    </Pressable>
                </View>
            </ScrollView>
        </SafeAreaView >
    )
}

const estilos = StyleSheet.create({
    conteinerGlobal: {
        flex: 1,
        backgroundColor: Cores.primariaClara,
    },

    conteiner: {
        padding: 20,
        gap: 5,
        flexDirection: 'column',
    },

    conteinerImagem: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    aDireita: {
        display: 'flex',
        flexDirection: 'row',
        marginLeft: 'auto',
        fontFamily: Fontes.baseRegular,
    },

    titulo: {
        fontSize: Fontes.grande1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
    },
    botaoRosa: {
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'center',
        backgroundColor: Cores.primariaEscura,
        fontFamily: Fontes.baseBold,
        color: Cores.fundo,
        width: '100%',
        height: 52,
        gap: 8,
        borderRadius: 16,
        marginTop: 4,
    },

    subTitulo: {
        fontSize: Fontes.medio1,
        color: Cores.subtitulo,
    },

    tituloCampo: {
        fontSize: Fontes.medio1,
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
    },

    campo: {
        width: 350,
        padding: 10,
        borderRadius: 15,
        gap: 5,
        marginBottom: 10,
        marginTop: 5,
        borderWidth: 2,
        display: 'flex',
        flexDirection: 'row',
        fontSize: Fontes.pequeno,
        borderColor: Cores.primariaClara,
        backgroundColor: Cores.fundo,
    },

    rotulo: {
        fontFamily: Fontes.baseBold,
        fontSize: Fontes.medio2,
        color: Cores.fundo
    },

    botao: {
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Cores.primariaEscura,
        fontFamily: Fontes.baseBold,
        color: Cores.fundo,
        width: 350,
        height: 40,
        borderRadius: 15,
    },

    mensagem: {
        color: Cores.erro,
        marginBottom: 10,
        fontSize: Fontes.pequeno,
        fontWeight: '500',
        padding: 5,
        borderRadius: 5,
        textAlign: 'center',
    },

    link: {
        fontFamily: Fontes.baseBold,
        fontSize: Fontes.medio1,
        color: Cores.primariaEscura,
        textDecorationLine: 'underline',
        marginLeft: 5,
    },


    icones: {
        width: 20,
        height: 20,
    },
    
    imagem: {
        width: 150,
        height: 150,
        borderRadius: '50%',
    },
    imagemConteiner: {
        marginRight: 10,
    },
    textoConteiner: {
        flex: 1,
    },
    seguranca: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Cores.primariaClara,
        color: Cores.subtitulo,
        margin: 15,
        padding: 10,
        width: 350,
        minHeight: 100,
        borderRadius: 5,
        borderWidth: 2,
        borderColor: Cores.secundariaClara,
    },
    texto: {
        flex: 1,
        fontSize: Fontes.pequeno,
        color: Cores.subtitulo,
    },
})