import { Text, StyleSheet, TextInput, Pressable, Alert, Image, View, ScrollView } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Cabecalho } from '@/components/Cabecalho'
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'
import { router } from 'expo-router'

export default function Sobre() {

    return (
        <SafeAreaView style={estilos.conteinerGlobal}>
            <Cabecalho />
            <ScrollView>
                <View style={estilos.conteiner}>
                    <Pressable
                        onPress={() => router.push('/home')}>
                        <Text style={estilos.subTitulo}>‹ Voltar</Text>
                    </Pressable>
                    <View style={estilos.conteinerTexto}>
                        <Text style={estilos.titulo}>Conheça nossa Plataforma</Text>
                        <Text style={estilos.subTitulo}>A plataforma Ísis - Você não está sozinha é uma aplicação mobile que visa o suporte emocional e psicológico para mulheres vítimas de violência.</Text>
                    </View>
                        <Text style={estilos.tituloCampo}>Nossos recursos e ferramentas</Text>

                    <View style={estilos.coluna}>
                        <View style={estilos.campo}>
                            <View style={estilos.conteinerIconeRosa}>
                                <Image
                                    style={estilos.icone}
                                    source={require('@/assets/icones/botaoRosa.png')}
                                />
                            </View>
                            <View style={estilos.conteinerTexto}>
                                <Text style={estilos.rotulo}>Botão de pânico</Text>
                                <Text style={estilos.texto}>Permite que a usuária solicite ajuda rapidamente em situações de emergência, oferecendo acesso imediato a contatos e recursos de proteção e suporte.</Text>
                            </View>



                        </View><View style={estilos.campo}>
                            <View style={estilos.conteinerIconeRosa}>
                                <Image
                                    style={estilos.icone}
                                    source={require('@/assets/icones/diarioRosa.png')}
                                />
                            </View>
                            <View style={estilos.conteinerTexto}>
                                <Text style={estilos.rotulo}>Botão de pânico</Text>
                                <Text style={estilos.texto}>Permite que a usuária solicite ajuda rapidamente em situações de emergência, oferecendo acesso imediato a contatos e recursos de proteção e suporte.</Text>
                            </View>
                        </View>


                        <View style={estilos.campo}>
                            <View style={estilos.conteinerIconeRosa}>
                                <Image
                                    style={estilos.icone}
                                    source={require('@/assets/icones/chatRosa.png')}
                                />
                            </View>
                            <View style={estilos.conteinerTexto}>
                                <Text style={estilos.rotulo}>Botão de pânico</Text>
                                <Text style={estilos.texto}>Permite que a usuária solicite ajuda rapidamente em situações de emergência, oferecendo acesso imediato a contatos e recursos de proteção e suporte.</Text>
                            </View>
                        </View>



                        <View style={estilos.campo}>
                            <View style={estilos.conteinerIconeRosa}>
                                <Image
                                    style={estilos.icone}
                                    source={require('@/assets/icones/locRosa.png')}
                                />
                            </View>
                            <View style={estilos.conteinerTexto}>
                                <Text style={estilos.rotulo}>Botão de pânico</Text>
                                <Text style={estilos.texto}>Permite que a usuária solicite ajuda rapidamente em situações de emergência, oferecendo acesso imediato a contatos e recursos de proteção e suporte.</Text>
                            </View>
                        </View>



                        <View style={estilos.campo}>
                            <View style={estilos.conteinerIconeRosa}>
                                <Image
                                    style={estilos.icone}
                                    source={require('@/assets/icones/infoRosa.png')}
                                />
                            </View>
                            <View style={estilos.conteinerTexto}>
                                <Text style={estilos.rotulo}>Botão de pânico</Text>
                                <Text style={estilos.texto}>Permite que a usuária solicite ajuda rapidamente em situações de emergência, oferecendo acesso imediato a contatos e recursos de proteção e suporte.</Text>
                            </View>
                        </View>
                    </View>
                    <Text style={estilos.titulo}>Nossa Equipe</Text>
                    <View style={estilos.linha}>
                        <View style={estilos.equipe}>
                            <Image
                                style={estilos.imagem}
                                source={require('@/assets/images/logo.png')} />
                            <Text style={estilos.tituloCampo}>Luane Caroline da Silva</Text>
                        </View>
                        <View style={estilos.equipe}>
                            <Image
                                style={estilos.imagem}
                                source={require('@/assets/images/logo.png')} />
                            <Text style={estilos.tituloCampo}>Milena Vaz de Abreu</Text>
                        </View>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

const estilos = StyleSheet.create({
    conteinerGlobal: {
        backgroundColor: Cores.primariaClara,
        flex: 1,
    },

    conteiner: {
        flexDirection: 'column',
        padding:20
    },
    conteinerTexto: {
        flex: 1,
        width: '65%',
    },
    linha: {
        flexDirection: 'row',
        gap: 20,
    },

    equipe: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    conteinerIconeRosa: {
        width: 44,
        height: 44,
        backgroundColor: Cores.primariaClara,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
    },

    conteinerIconeRoxo: {
        width: 44,
        height: 44,
        backgroundColor: Cores.secundariaClara,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 12,
    },
    coluna: {
        alignItems: 'center',
    },

    titulo: {
        fontSize: Fontes.grande1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        paddingVertical: 6,
        lineHeight: Fontes.grande1 * 1.2,
    },
    tituloCampo: {
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
        fontSize: Fontes.medio2,
    },

    texto: {
        flex: 1,
        fontSize: Fontes.pequeno,
        color: Cores.subtitulo,
    },

    subTitulo: {
        flex: 1,
        fontSize: Fontes.medio2,
        color: Cores.subtitulo,
        marginBottom: 14,
        lineHeight: 20,
    },


    rotulo: {
        fontSize: Fontes.medio1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
    },

    lerMais: {
        fontSize: Fontes.pequeno,
        fontFamily: Fontes.baseBold,
        color: Cores.primariaEscura,
    },

    imagem: {
        width: 100,
        height: 100,
        borderRadius: '50%',
    },

    icone: {
        width: 30,
        height: 30,
    },
    campo: {
        flex: 1,
        padding: 10,
        gap: 10,
        borderRadius: 15,
        marginBottom: 10,
        borderWidth: 1,
        flexDirection: 'row',
        alignItems: 'center',
        fontSize: Fontes.pequeno,
        borderColor: Cores.primaria,
        backgroundColor: Cores.fundo,
    },
    campoBranco: {
        padding: 10,
        borderRadius: 15,
        marginBottom: 10,
        fontSize: Fontes.pequeno,
        backgroundColor: Cores.fundo,
    },
})
