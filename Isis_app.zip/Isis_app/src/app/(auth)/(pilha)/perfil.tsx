
import { useState } from 'react'
import { router, Link, Color } from 'expo-router'
import { Text, StyleSheet, TextInput, Pressable, Alert, Image, View, ScrollView } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Cabecalho } from '@/components/Cabecalho'
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'
import { useAutenticacao } from '@/hooks/useAutenticacao'

export default function Perfil() {
        const {deslogar, deslogarContexto} = useAutenticacao()

        const voltar = () => {
            router.replace('/(auth)/home')
        }

    const sair = async () => {
        await deslogar()
        await deslogarContexto()
        router.replace('/')
    }
    return (
        <SafeAreaView style={estilos.conteinerGlobal}>
            <Cabecalho />
            <ScrollView>
                <View style={estilos.conteiner}>
                    <Pressable
                        onPress={voltar}>
                        <Text style={estilos.texto}>‹ Voltar</Text> 
                    </Pressable>
                    <View style={estilos.conteinerImagem}>
                        <Image
                            style={estilos.imagem}
                            source={require('@/assets/images/logo.png')}
                        />
                        <Text style={estilos.tituloCampo}>Fulana de tal</Text>
                    </View>
                    <Pressable
                        style={estilos.campo}
                        onPress={() => router.push('/conta')}>
                        <Image
                            style={estilos.icones}
                            source={require('@/assets/icones/usuario.png')}
                        />
                        <Text style={estilos.texto}>Minha conta</Text>
                        <Text style={estilos.seta}>{'>'}</Text>
                    </Pressable>

                    <Pressable
                        style={estilos.campo}
                        onPress={() => router.push('/gerenciarSenha')}>
                        <Image
                            style={estilos.icones}
                            source={require('@/assets/icones/trancar.png')}
                        />
                        <Image />
                        <Text style={estilos.texto}>Gerenciar Senha</Text>
                        <Text style={estilos.seta}>{'>'}</Text>
                    </Pressable>
                    <Pressable
                        style={estilos.campo}>
                        <Image
                            style={estilos.icones}
                            source={require('@/assets/icones/adicionarUsuario.png')}
                        />
                        <Image />
                        <Text style={estilos.texto}>Contato de Emergência</Text>
                       <Text style={estilos.seta}>{'>'}</Text>
                    </Pressable>
                    <Pressable
                        style={estilos.campo}>
                        <Image
                            style={estilos.icones}
                            source={require('@/assets/icones/configuracoes.png')}
                        />
                        <Image />
                        <Text style={estilos.texto}>Configurações</Text>
                        <Text style={estilos.seta}>{'>'}</Text>
                    </Pressable>

                    <Pressable
                        style={estilos.campo}>
                        <Image
                            style={estilos.icones}
                            source={require('@/assets/icones/central.png')}
                        />
                        <Image />
                        <Text style={estilos.texto}>Central de Ajuda</Text>
                        <Text style={estilos.seta}>{'>'}</Text>
                    </Pressable>

                    <Pressable
                        style={estilos.campo}
                        onPress={sair}
                        >
                        <Image
                            style={estilos.icones}
                            source={require('@/assets/icones/sair.png')}
                        />
                        <Image />
                        <Text style={estilos.texto}>Sair</Text>
                        <Text style={estilos.seta}>{'>'}</Text>
                    </Pressable>
                </View>
            </ScrollView>
        </SafeAreaView >
    )
}

const estilos = StyleSheet.create({
    conteinerGlobal: {
        flex: 1,
        flexDirection: 'column',
        backgroundColor: Cores.primariaClara,
    },

    conteiner: {
        padding: 20,
        flex: 1,
        flexDirection: 'column',
        backgroundColor: Cores.primariaClara,
    },

    conteinerImagem: {
        alignItems: 'center',
        justifyContent: 'center',
    },

    titulo: {
        fontSize: Fontes.extraGrande,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        padding: 10,
        transform: [{ scaleY: 1.2 }],
    },

    texto: {
        fontSize: Fontes.medio1,
        color: Cores.subtitulo,
    },

    seta: {
        marginLeft: 'auto',
        fontSize: Fontes.medio1,
        color: Cores.subtitulo,
        fontFamily: Fontes.baseBold
    },

    tituloCampo: {
        fontSize: Fontes.medio2,
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
    },

    campo: {
        width: 350,
        padding: 10,
        borderRadius: 15,
        gap: 5,
        marginBottom: 10,
        marginTop: 5,
        borderWidth: 2,
        display: 'flex',
        flexDirection: 'row',
        fontSize: Fontes.pequeno,
        borderColor: Cores.primariaClara,
        backgroundColor: Cores.fundo,
    },

    rotulo: {
        fontFamily: Fontes.baseBold,
        fontSize: Fontes.medio2,
        color: Cores.fundo
    },

    botao: {
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Cores.primariaEscura,
        fontFamily: Fontes.baseBold,
        color: Cores.fundo,
        width: 350,
        height: 40,
        borderRadius: 15,
    },

    mensagem: {
        color: Cores.erro,
        marginBottom: 10,
        fontSize: Fontes.pequeno,
        fontWeight: '500',
        padding: 5,
        borderRadius: 5,
        textAlign: 'center',
    },

    link: {
        fontFamily: Fontes.baseBold,
        fontSize: Fontes.medio1,
        color: Cores.primariaEscura,
        textDecorationLine: 'underline',
        marginLeft: 5,
    },


    icones: {
        width: 20,
        height: 20,
    },
    imagem: {
        width: 150,
        height: 150,
        borderRadius: '50%',
    },
    textoConteiner: {
        flex: 1,
    },
    seguranca: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Cores.primariaClara,
        color: Cores.subtitulo,
        margin: 15,
        padding: 10,
        width: 350,
        minHeight: 100,
        borderRadius: 5,
        borderWidth: 2,
        borderColor: Cores.secundariaClara,
    },

    conteinerTexto: {
        flex: 1,
        width: '65%',
    }, campoLinha: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 16,
        padding: 16,
        borderRadius: 20,
        marginVertical: 8,
        borderWidth: 0,
        width: '100%',
        backgroundColor: Cores.fundo,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.08,
        shadowRadius: 10,
        elevation: 3,
    },

    conteinerIconeEspirito: {
        width: 50,
        height: 50,
        paddingVertical: 14,
        borderRadius: 16,
        gap: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Cores.secundariaClara,
    },

    dataCampo: {
        position: 'absolute',
        top: 22,
        right: 20,
        fontSize: Fontes.pequeno,
        fontFamily: Fontes.baseBold,
        color: Cores.primariaEscura,
    },
    conteinerRoxo: {
        width: 44,
        height: 44,
        backgroundColor: Cores.secundaria,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
    },

    lista: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        paddingVertical: 5,
        gap: 20,
        justifyContent: 'center',
    },

    entrada: {
        fontSize: Fontes.pequeno,
        color: Cores.subtitulo,
        borderColor: Cores.primariaClara,
        borderWidth: 1,
        borderRadius: 14,
        width: '100%',
        minHeight: 140,
        padding: 14,
        textAlignVertical: 'top',
    },

    campoRoxo: {
        borderColor: Cores.secundaria,
        padding: 10,
        gap: 10,
        width: '100%',
        borderRadius: 15,
        marginBottom: 10,
        borderWidth: 1,
        flexDirection: 'row',
        fontSize: Fontes.pequeno,
        backgroundColor: Cores.secundariaClara,

    },
    conteinerIconeRosa: {
        width: 44,
        height: 44,
        backgroundColor: Cores.primariaClara,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
    },
    conteinerIconeRoxoRedondo: {

        width: 44,
        height: 44,
        backgroundColor: Cores.secundariaClara,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',

    },

    fileira: {
        flexDirection: 'row',
        gap: 10,
    },

    textoRoxo: {
        fontFamily: Fontes.baseRegular,
        fontSize: Fontes.pequeno,
        color: Cores.secundaria,
    },

    textoRosa: {

        fontSize: Fontes.medio1,
        color: Cores.primariaEscura,
    },
    iconePequeno: {
        width: 15,
        height: 15,
    },

    botaoRosa: {
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'center',
        backgroundColor: Cores.primariaEscura,
        fontFamily: Fontes.baseBold,
        color: Cores.fundo,
        width: '100%',
        height: 52,
        gap: 8,
        borderRadius: 16,
        marginTop: 4,
    },

    icone: {
        width: 20,
        height: 20,
    },
    conteudoRegistro: {
        flex: 1,
    },

    corpoRegistro: {
        borderBottomColor: Cores.primariaClara,
        borderBottomWidth: 1,
        paddingBottom: 10,
        marginBottom: 10,
        gap: 4,
    },

    dataRegistro: {
        fontSize: Fontes.medio1,
        fontFamily: Fontes.baseRegular,
        color: Cores.primariaEscura,
    },

    acoesRegistro: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 28,
    },

    acaoRegistro: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
    },
})