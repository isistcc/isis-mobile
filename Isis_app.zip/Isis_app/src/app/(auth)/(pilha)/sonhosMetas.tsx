import { Text, StyleSheet, TextInput, Pressable, Alert, Image, View, ScrollView } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Cabecalho } from '@/components/Cabecalho'
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'
import { router } from 'expo-router'

export default function SonhosMetas() {

    return (
        <SafeAreaView style={estilos.conteinerGlobal}>
            <Cabecalho />
            <ScrollView style={estilos.conteiner}>
                <Pressable
                    onPress={() => router.push('/diarioDigital')}>
                    <Text style={estilos.subTitulo}>‹ Voltar</Text>
                </Pressable>

                <View style={estilos.cartaoPrincipal}>
                    <View style={estilos.conteinerIcone}>
                        <Image
                            style={estilos.icone}
                            source={require('@/assets/icones/estrela.png')}
                        />
                    </View>
                    <View style={estilos.conteinerTexto}>
                        <Text style={estilos.titulo}>Novos sonhos e metas</Text>
                        <Text style={estilos.subTitulo}>Defina novos sonhos, estabeleça suas metas e alcance o futuro que deseja.</Text>
                    </View>
                </View>
                <View style={estilos.coluna}>
                    <View style={estilos.campo}>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Sobre essa etapa</Text>
                            <Text style={estilos.texto}>Aqui, você pode definir novos sonhos e metas, organizar seus objetivos e acompanhar cada conquista ao longo do seu recomeço.</Text>
                        </View>
                    </View>
                </View>


                <Text style={estilos.tituloCampo}>Atividades</Text>

                <View style={estilos.coluna}>
                    <Pressable style={estilos.campo}>
                        <View style={estilos.conteinerIconeRosa}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/coracaoRosa.png')}
                            />
                        </View>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Meu maior sonho</Text>
                            <Text style={estilos.texto}>Escreva algo que você gostaria de realizar no futuro.</Text>
                        </View>
                    </Pressable>

                    <Pressable style={estilos.campo}>
                        <View style={estilos.conteinerIconeRoxo}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/meditacao.png')}
                            />
                        </View>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Pequenos passos</Text>
                            <Text style={estilos.texto}>Escolha uma meta e pense em uma pequena ação para começar.</Text>
                        </View>
                    </Pressable>


                    <Pressable style={estilos.campo}>
                        <View style={estilos.conteinerIconeRosa}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/sorrisoRosa.png')}
                            />
                        </View>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Coisas que quero aprender</Text>
                            <Text style={estilos.texto}>Liste algo novo que você gostaria de aprender ou experimentar.</Text>
                        </View>
                    </Pressable>

                    <Pressable style={estilos.campo}>
                        <View style={estilos.conteinerIconeRoxo}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/estrelaRoxa.png')}
                            />
                        </View>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Meu futuro ideal</Text>
                            <Text style={estilos.texto}>Imagine como gostaria que sua vida estivesse daqui a algum tempo e registre suas ideias.</Text>
                        </View>
                    </Pressable>

                    <Pressable style={estilos.campo}>
                        <View style={estilos.conteinerIconeRosa}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/maos.png')}
                            />
                        </View>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Carta para o meu futuro</Text>
                            <Text style={estilos.texto}>Escreva uma mensagem para você mesma contando o que espera conquistar.</Text>
                        </View>
                    </Pressable>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

const estilos = StyleSheet.create({

    conteinerGlobal: {
        flex: 1,
        backgroundColor: Cores.primariaClara,
        flexDirection: 'column'
    },

    conteiner: {
        padding: 20,
    },

    cartaoPrincipal: {
        flexDirection: 'row',
        width: '100%',
        maxWidth: 350,
        alignItems: 'center',
        backgroundColor: Cores.primariaClara,
        borderRadius: 15,
        gap: 16,
        padding: 20,
    },

    conteinerIcone: {
        width: 60,
        height: 60,
        backgroundColor: Cores.primariaClara,
        borderRadius: 15,
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.4,
        shadowRadius: 10,
        elevation: 3,
    },
    conteinerIconeRosa: {
        width: 44,
        height: 44,
        backgroundColor: Cores.primariaClara,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
    },

    conteinerIconeRoxo: {
        width: 44,
        height: 44,
        backgroundColor: Cores.secundariaClara,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
    },

    conteinerTexto: {
        flex: 1,
        flexShrink: 1,
        minWidth: 0,
    },
    coluna: {
        alignItems: 'center',
    },

    titulo: {
        fontSize: Fontes.grande1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        paddingVertical: 6,
    },
    tituloCampo: {
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
    },
    subTitulo: {
        fontSize: Fontes.medio2,
        color: Cores.subtitulo,
    },

    texto: {
        flex: 1,
        fontSize: Fontes.medio1,
        color: Cores.subtitulo,
    },
    rotulo: {
        fontSize: Fontes.medio1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        textAlign: 'center',
    },

    lerMais: {
        fontSize: Fontes.pequeno,
        fontFamily: Fontes.baseBold,
        color: Cores.primariaEscura,
    },

    imagem: {
        width: 300,
        height: 300,
    },

    icone: {
        width: 30,
        height: 30,
    },
    campo: {
        padding: 10,
        gap: 10,
        width: '100%',
        maxWidth: 350,
        borderRadius: 15,
        marginBottom: 10,
        borderWidth: 1,
        flexDirection: 'row',
        alignItems: 'center',
        fontSize: Fontes.pequeno,
        borderColor: Cores.primaria,
        backgroundColor: Cores.fundo,
    },
})