import { Stack } from 'expo-router'
import { StatusBar } from 'expo-status-bar'
import { SafeAreaProvider } from 'react-native-safe-area-context'

export default function PilhaLayout() {

  return (
    <SafeAreaProvider>
      <StatusBar style='light' />
      <Stack screenOptions={{headerShown: false}}>
        <Stack.Screen name='conta' />
        <Stack.Screen name='gerenciarSenha' />
        <Stack.Screen name='perfil' />
        <Stack.Screen name='informacoes' />
        <Stack.Screen name='sobre' />
      </Stack>
    </SafeAreaProvider>
  )
}
