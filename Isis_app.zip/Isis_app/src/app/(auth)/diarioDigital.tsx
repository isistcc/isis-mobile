import { Cabecalho } from '@/components/Cabecalho'
import { Text, StyleSheet, Pressable, Image, View, TextInput, ScrollView } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { router } from 'expo-router'
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'
import { RegistroTipo } from '@/types/Registro'

export default function DiarioDigital() {
    return (
        <SafeAreaView style={estilos.conteinerGlobal}>
            <Cabecalho />
            <ScrollView style={estilos.conteiner}>
                <View style={estilos.conteinerTexto}>
                    <Pressable
                        onPress={() => router.push('/home')}>
                        <Text style={estilos.subTitulo}>‹ Voltar</Text>
                    </Pressable>
                    <Text style={estilos.titulo}>Diário Digital</Text>
                    <Text style={estilos.subTitulo}>Registre seus dias, sentimentos e progressos. Escrever pode ajudar você a se fortalecer e acompanhar sua jornada.</Text>
                </View>

                <View style={estilos.campoLinha}>
                    <Image
                        style={{
                            width: 30,
                            height: 30,
                        }}
                        source={require('@/assets/icones/cofre.png')} />
                    <View>
                        <Text style={estilos.tituloCampo}>Cofre digital</Text>
                        <Text style={estilos.texto}>Faça upload de fotos, aúdios e documentos que apenas você terá acesso.</Text>
                    </View>
                </View>

                <View style={estilos.campoLinha}>
                    <Image
                        style={{
                            width: 15,
                            height: 15,
                        }}
                        source={require('@/assets/icones/clip.png')} />
                    <Text style={estilos.texto}>Clique aqui para anexar suas fotos, vídeos ou documentos</Text>
                </View>

                <View style={estilos.campoColuna}>
                    <Text style={estilos.tituloCampo}>Como você está hoje?</Text>
                    <Text style={estilos.texto}>Escolha seu estado de espírito</Text>
                    <View style={estilos.lista}>
                        <View style={estilos.conteinerIconeEspirito}>
                            <Image
                                style={{
                                    width: 15,
                                    height: 15,
                                }}
                                source={require('@/assets/icones/feliz.png')} />
                            <Text style={estilos.textoRoxo}>Feliz</Text>
                        </View>
                        <View style={estilos.conteinerIconeEspirito}>
                            <Image
                                style={{
                                    width: 15,
                                    height: 15,
                                }}
                                source={require('@/assets/icones/bem.png')} />
                            <Text style={estilos.textoRoxo}>Bem</Text>
                        </View>
                        <View style={estilos.conteinerIconeEspirito}>
                            <Image
                                style={{
                                    width: 15,
                                    height: 15,
                                }}
                                source={require('@/assets/icones/neutra.png')} />
                            <Text style={estilos.textoRoxo}>Neutra</Text>
                        </View>
                        <View style={estilos.conteinerIconeEspirito}>
                            <Image
                                style={{
                                    width: 15,
                                    height: 15,
                                }}
                                source={require('@/assets/icones/triste.png')} />
                            <Text style={estilos.textoRoxo}>Triste</Text>
                        </View>
                        <View style={estilos.conteinerIconeEspirito}>
                            <Image
                                style={{
                                    width: 15,
                                    height: 15,
                                }}
                                source={require('@/assets/icones/irritada.png')} />
                            <Text style={estilos.textoRoxo}>Irritada</Text>
                        </View>
                    </View>
                </View>



                <View style={estilos.campoColuna}>
                    <Text style={estilos.tituloCampo}>Escreva sobre seu dia</Text>
                    <Text style={estilos.dataCampo}>DD de MMMMM de AAAA</Text>
                    <TextInput
                        style={estilos.entrada}
                        placeholder='Como foi o seu dia? Conte aqui o que sente, o que aconteceu ou o que deseja lembrar...'
                        placeholderTextColor={Cores.subtitulo}
                    >
                    </TextInput>
                    <Pressable style={estilos.botaoRosa}>
                        <Image
                            style={{
                                width: 15,
                                height: 15,
                            }}
                            source={require('@/assets/icones/lapis.png')} />
                        <Text style={{
                            fontSize: Fontes.medio1,
                            fontFamily: Fontes.baseBold,
                            color: Cores.fundo,
                        }}
                        >Salvar registro</Text>
                    </Pressable>
                </View>
                <Text style={estilos.tituloCampo}>Seus registros</Text>
                <View style={estilos.campoLinha}>
                    <View style={estilos.conteinerIconeEspirito}>
                        <Image
                            style={{ width: 20, height: 20, tintColor: Cores.secundaria }}
                            source={require('@/assets/icones/feliz.png')} />
                        <Text style={estilos.textoRoxo}>Feliz</Text>
                    </View>
                    <View style={estilos.conteudoRegistro}>
                        <View style={estilos.corpoRegistro}>
                            <Text style={estilos.dataRegistro}>DD de MMMMM de AAAA</Text>
                            <Text style={estilos.texto}>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</Text>
                        </View>
                        <View style={estilos.acoesRegistro}>
                            <View style={estilos.acaoRegistro}>
                                <Image
                                    style={{ width: 15, height: 15 }}
                                    source={require('@/assets/icones/editar.png')} />
                                <Text style={{
                                    fontFamily: Fontes.baseRegular,
                                    fontSize: Fontes.pequeno,
                                    color: Cores.secundariaEscura,}}>Editar</Text>
                            </View>

                            <View style={estilos.acaoRegistro}>
                                <Image
                                    style={{ width: 15, height: 15 }}
                                    source={require('@/assets/icones/excluir.png')} />
                                <Text style={{
                                    fontFamily: Fontes.baseRegular,
                                    fontSize: Fontes.pequeno,
                                    color: Cores.secundariaEscura,
                                }}>Excluir</Text>
                            </View>
                        </View>
                    </View>
                </View>



                <Text style={estilos.tituloCampo}>Etapas do seu plano de reconstrução</Text>
                <Pressable style={estilos.campoLinha}
                    onPress={() => router.push('/(pilha)/cuidado')}
                >
                    <View style={estilos.conteinerIconeRosa}>
                        <Image
                            style={estilos.icone}
                            source={require('@/assets/icones/autocuidado.png')}
                        />
                    </View>
                    <View style={estilos.conteinerTexto}>
                        <Text style={estilos.tituloCampo}>Cuidado comigo</Text>
                        <Text style={estilos.texto}>Priorize sua saúde mental e física. Reconheça seu valor e pratique o autocuidado.</Text>
                    </View>
                </Pressable>


                <Pressable style={estilos.campoLinha}
                    onPress={() => router.push('/(pilha)/conhecimento')}
                >
                    <View style={estilos.conteinerIconeRoxoRedondo}>
                        <Image
                            style={estilos.icone}
                            source={require('@/assets/icones/livro.png')}
                        />
                    </View>
                    <View style={estilos.conteinerTexto}>
                        <Text style={estilos.tituloCampo}>Conhecimento e informações</Text>
                        <Text style={estilos.texto}>Aprenda sobre seus direitos, tipos de violência e como se proteger.</Text>
                    </View>
                </Pressable>


                <Pressable style={estilos.campoLinha}
                    onPress={() => router.push('/(pilha)/autonomia')}>
                    <View style={estilos.conteinerIconeRosa}>
                        <Image
                            style={estilos.icone}
                            source={require('@/assets/icones/maleta.png')}
                        />
                    </View>
                    <View style={estilos.conteinerTexto}>
                        <Text style={estilos.tituloCampo}>Autonmia e independência</Text>
                        <Text style={estilos.texto}>Conquiste autonomia financeira, profissional e fortaleça sua independência.</Text>
                    </View>
                </Pressable>

                <Pressable style={estilos.campoLinha}
                    onPress={() => router.push('/(pilha)/redes')}>
                    <View style={estilos.conteinerIconeRoxoRedondo}>
                        <Image
                            style={estilos.icone}
                            source={require('@/assets/icones/pessoasRoxo.png')}
                        />
                    </View>
                    <View style={estilos.conteinerTexto}>
                        <Text style={estilos.tituloCampo}>Rede de apoio</Text>
                        <Text style={estilos.texto}>Construa e fortaleça sua rede de apoio com pessoas que te acolhem.</Text>
                    </View>
                </Pressable>


                <Pressable style={estilos.campoLinha}
                    onPress={() => router.push('/(pilha)/sonhosMetas')}>
                    <View style={estilos.conteinerIconeRosa}>
                        <Image
                            style={estilos.icone}
                            source={require('@/assets/icones/estrela.png')}
                        />
                    </View>
                    <View style={estilos.conteinerTexto}>
                        <Text style={estilos.tituloCampo}>Novos sonhos e metas</Text>
                        <Text style={estilos.texto}>Recomece, realize seus sonhos e construa o futuro que você merece.</Text>
                    </View>
                </Pressable>


                <Pressable style={estilos.campoRoxo}>
                    <View style={estilos.conteinerRoxo}>
                        <Image
                            style={estilos.icone}
                            source={require('@/assets/icones/brilhos.png')}
                        />
                    </View>
                    <View style={estilos.conteinerTexto}>
                        <Text style={estilos.tituloCampo}>Motivação do dia</Text>
                        <Text style={estilos.texto}>Você já enfrentou muitas coisas e sobreviveu.  {'\n'} Você é mais forte do que imagina.</Text>
                    </View>

                    <Image
                        style={{
                            height: 30,
                            width: 30,
                        }}
                        source={require('@/assets/icones/coracao.png')}
                    />
                </Pressable>
            </ScrollView >
        </SafeAreaView >
    )
}

const estilos = StyleSheet.create({

    conteinerGlobal: {
        flex: 1,
        backgroundColor: Cores.primariaClara,
        flexDirection: 'column'
    },

    conteiner: {
        padding: 20,
    },

    conteinerTexto: {
        flex: 1,
        width: '65%',
    }, campoLinha: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 16,
        padding: 16,
        borderRadius: 20,
        marginVertical: 8,
        borderWidth: 0,
        width: '100%',
        backgroundColor: Cores.fundo,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.08,
        shadowRadius: 10,
        elevation: 3,
    },

    conteinerIconeEspirito: {
        width: 50,
        height: 50,
        paddingVertical: 14,
        borderRadius: 16,
        gap: 5,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Cores.secundariaClara,
    },

    campoColuna: {
        position: 'relative',
        padding: 20,
        gap: 5,
        width: '100%',
        borderRadius: 20,
        marginVertical: 8,
        borderWidth: 0,
        flexDirection: 'column',
        fontSize: Fontes.pequeno,
        backgroundColor: Cores.fundo,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.08,
        shadowRadius: 10,
        elevation: 3,
    },

    dataCampo: {
        position: 'absolute',
        top: 22,
        right: 20,
        fontSize: Fontes.pequeno,
        fontFamily: Fontes.baseBold,
        color: Cores.primariaEscura,
    },
    conteinerRoxo: {
        width: 44,
        height: 44,
        backgroundColor: Cores.secundaria,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
    },

    lista: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        paddingVertical: 5,
        gap: 20,
        justifyContent: 'center',
    },

    entrada: {
        fontSize: Fontes.pequeno,
        color: Cores.subtitulo,
        borderColor: Cores.primariaClara,
        borderWidth: 1,
        borderRadius: 14,
        width: '100%',
        minHeight: 140,
        padding: 14,
        textAlignVertical: 'top',
    },

    campoRoxo: {
        borderColor: Cores.secundaria,
        padding: 10,
        gap: 10,
        width: '100%',
        borderRadius: 15,
        marginBottom: 10,
        borderWidth: 1,
        flexDirection: 'row',
        fontSize: Fontes.pequeno,
        backgroundColor: Cores.secundariaClara,

    },
    conteinerIconeRosa: {
        width: 44,
        height: 44,
        backgroundColor: Cores.primariaClara,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
    },
    conteinerIconeRoxoRedondo: {

        width: 44,
        height: 44,
        backgroundColor: Cores.secundariaClara,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',

    },

    fileira: {
        flexDirection: 'row',
        gap: 10,
    },



    titulo: {
        fontSize: Fontes.grande1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        paddingVertical: 6,
        lineHeight: Fontes.grande1 * 1.2,
    },
    tituloCampo: {
        fontSize: Fontes.medio1,
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
    },
    subTitulo: {
        flex: 1,
        fontSize: Fontes.medio2,
        color: Cores.subtitulo,
    },

    texto: {
        flex: 1,
        fontSize: Fontes.pequeno,
        color: Cores.subtitulo,
    },
    textoRoxo: {
        fontFamily: Fontes.baseRegular,
        fontSize: Fontes.pequeno,
        color: Cores.secundaria,
    },

    textoRosa: {

        fontSize: Fontes.medio1,
        color: Cores.primariaEscura,
    },
    iconePequeno: {
        width: 15,
        height: 15,
    },
    rotulo: {
        fontSize: Fontes.medio1,
        fontFamily: Fontes.baseBold,
        color: Cores.fundo,
        textAlign: 'center',
    },

    botaoRosa: {
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'center',
        backgroundColor: Cores.primariaEscura,
        fontFamily: Fontes.baseBold,
        color: Cores.fundo,
        width: '100%',
        height: 52,
        gap: 8,
        borderRadius: 16,
        marginTop: 4,
    },

    imagem: {
        width: 300,
        height: 300,
    },

    icone: {
        width: 20,
        height: 20,
    },
    conteudoRegistro: {
        flex: 1,
    },

    corpoRegistro: {
        borderBottomColor: Cores.primariaClara,
        borderBottomWidth: 1,
        paddingBottom: 10,
        marginBottom: 10,
        gap: 4,
    },

    dataRegistro: {
        fontSize: Fontes.medio1,
        fontFamily: Fontes.baseRegular,
        color: Cores.primariaEscura,
    },

    acoesRegistro: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 28,
    },

    acaoRegistro: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
    },
})