import { Text, StyleSheet, Pressable, Image, View, ScrollView } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { router } from 'expo-router'
import { Cabecalho } from '@/components/Cabecalho'
import { Fontes } from '@/constants/Fontes'
import { Cores } from '@/constants/Cores'

export default function Home() {
    return (
        <SafeAreaView style={estilos.conteinerGlobal}>
            <Cabecalho />
            <ScrollView style={estilos.conteiner}>
            <View style={estilos.secao1}>
                <View style={estilos.conteinerTxtBotoes}>
                    <Text style={estilos.titulo}>Você não está sozinha.</Text>
                    <Text style={estilos.subTitulo}>
                        A plataforma Ísis foi criada para apoiar mulheres que passaram por qualquer tipo de violência.
                        Aqui você encontra ajuda, informação e acolhimento.
                    </Text>
                    <View style={estilos.conteinerBotoes}>
                        <Pressable style={estilos.botaoRosa}>
                            <Image
                                style={estilos.iconeBotao}
                                source={require('@/assets/icones/escudo2.png')}
                            />
                            <Text style={estilos.textoBotaoRosa}>Preciso de ajuda</Text>
                        </Pressable>
                        <Pressable style={estilos.botaoRoxo}>
                            <Image
                                style={estilos.iconeBotao}
                                source={require('@/assets/icones/chatIcon.png')}
                            />
                            <Text style={estilos.textoBotaoRoxo}>Falar com alguém</Text>
                        </Pressable>
                    </View>
                </View>
                <Image
                    style={estilos.imagem}
                    resizeMode="contain"
                    source={require('@/assets/images/mulheres.png')}
                />
            </View>

            <View style={estilos.secao2}>
                <Text style={estilos.titulo}>Acesso rápido</Text>
                <View style={estilos.lista}>
                    <Pressable style={estilos.botaoAcesso}
                        onPress={() => router.push('/botaoPanico')}
                    >
                        <View style={estilos.conteinerIcone}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/botaoRosa.png')}
                            />
                        </View>
                        <Text style={estilos.rotulo}>Botão de pânico</Text>
                        <Text style={estilos.descricao}>Pressione quando necessário</Text>
                    </Pressable>

                    <Pressable style={estilos.botaoAcesso}
                        onPress={() => router.push('/diarioDigital')}>
                        <View style={estilos.conteinerIcone}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/diarioRosa.png')}
                            />
                        </View>
                        <Text style={estilos.rotulo}>Diário digital</Text>
                        <Text style={estilos.descricao}>Registre seus dias e progresso</Text>
                    </Pressable>

                    <Pressable style={estilos.botaoAcesso}
                        onPress={() => router.push('/chatConversa')}>
                        <View style={estilos.conteinerIcone}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/chatRosa.png')}
                            />
                        </View>
                        <Text style={estilos.rotulo}>Chat de conversa</Text>
                        <Text style={estilos.descricao}>Converse com aquelas que te entendem</Text>
                    </Pressable>

                    <Pressable style={estilos.botaoAcesso}
                    onPress={() => router.push('/redesApoio')}>
                        <View style={estilos.conteinerIcone}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/locRosa.png')}
                            />
                        </View>
                        <Text style={estilos.rotulo}>Redes de apoio</Text>
                        <Text style={estilos.descricao}>Encontre serviços de apoio da sua região</Text>
                    </Pressable>
                </View>
            </View>

            <View style={estilos.secao3}>
                <View>
                    <Text style={estilos.titulo}>Informações que protegem</Text>
                </View>
                <View style={estilos.lista}>
                    <Pressable style={estilos.botaoInfo}
                    onPress={() => router.push('/informacoes')}
                    
                    >
                        <View style={estilos.conteinerIconeRoxo}>
                            <Image
                                style={estilos.iconeRoxo}
                                source={require('@/assets/icones/tiposViolencia.png')}
                            />
                        </View>
                        <View style={estilos.textoInfo}>
                            <Text style={estilos.rotuloRoxo}>Tipos de violência</Text>
                            <Text style={estilos.subTituloInfo}>Entenda os diferentes tipos de violência.</Text>
                            <Text style={estilos.lerMais}>Ler mais ›</Text>
                        </View>
                    </Pressable>

                    <Pressable style={estilos.botaoInfo}
                    onPress={() => router.push('/informacoes')}>
                        <View style={estilos.conteinerIconeRoxo}>
                            <Image
                                style={estilos.iconeRoxo}
                                source={require('@/assets/icones/leisDreitos.png')}
                            />
                        </View>
                        <View style={estilos.textoInfo}>
                            <Text style={estilos.rotuloRoxo}>Leis & Direitos</Text>
                            <Text style={estilos.subTituloInfo}>Conheça seus direitos e como a lei te protege.</Text>
                            <Text style={estilos.lerMais}>Ler mais ›</Text>
                        </View>
                    </Pressable>

                    <Pressable style={estilos.botaoInfo}
                    onPress={() => router.push('/informacoes')}>
                        <View style={estilos.conteinerIconeRoxo}>
                            <Image
                                style={estilos.iconeRoxo}
                                source={require('@/assets/icones/comoDenunciar.png')}
                            />
                        </View>
                        <View style={estilos.textoInfo}>
                            <Text style={estilos.rotuloRoxo}>Como denunciar</Text>
                            <Text style={estilos.subTituloInfo}>Saiba o que fazer e como denunciar uma violência.</Text>
                            <Text style={estilos.lerMais}>Ler mais ›</Text>
                        </View>
                    </Pressable>
                </View>
            </View>
        </ScrollView>
        </SafeAreaView>
    )
}

const estilos = StyleSheet.create({
    conteinerGlobal: {
        flex: 1,
        backgroundColor: Cores.fundo,
    },

    conteiner: {
        width: '100%',
        backgroundColor: Cores.fundo,
    },

    conteinerTxtBotoes: {
        width: '58%',
    },

    titulo: {
        fontSize: Fontes.grande1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        paddingVertical: 6,
        lineHeight: Fontes.grande1 * 1.2,
    },

    subTitulo: {
        fontSize: Fontes.medio1,
        color: Cores.subtitulo,
        marginBottom: 14,
        lineHeight: 20,
    },

    conteinerBotoes: {
        flexDirection: 'row',
        gap: 12,
    },

    botaoRosa: {
        backgroundColor: Cores.primariaEscura,
        borderRadius: 25,
        paddingVertical: 10,
        paddingHorizontal: 14,
        gap: 7,
        flexDirection: 'row',
        alignItems: 'center',
    },

    textoBotaoRosa: {
        color: Cores.fundo,
        fontFamily: Fontes.baseBold,
        fontSize: Fontes.pequeno,
    },

    botaoRoxo: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 10,
        paddingHorizontal: 14,
        gap: 7,
        borderWidth: 1.5,
        borderRadius: 25,
        borderColor: Cores.secundariaClara,
    },

    textoBotaoRoxo: {
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
        fontSize: Fontes.pequeno,
    },

    iconeBotao: {
        width: 18,
        height: 18,
    },

    conteinerIcone: {
        width: 44,
        height: 44,
        backgroundColor: Cores.secundariaClara,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 12,
    },
    conteinerIconeRoxo: {
        width: 40,
        height: 60,
        backgroundColor: Cores.secundariaClara,
        borderRadius: 10,
        alignItems: 'center',
        justifyContent: 'center',
    },

    botaoAcesso: {
        backgroundColor: Cores.fundo,
        borderRadius: 15,
        flex: 1,
        minHeight: 130,
        paddingVertical: 16,
        paddingHorizontal: 10,
        alignItems: 'center',
        justifyContent: 'flex-start',
    },

    botaoInfo: {
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 3,
        },
        shadowOpacity: 0.08,
        shadowRadius: 8,
        elevation: 2,

        backgroundColor: Cores.fundo,
        borderRadius: 15,
        flexBasis: '30%',
        flexGrow: 1,
        padding: 3,
        flexDirection: 'row',
        alignItems: 'flex-start',
        gap: 3,
    },

    textoInfo: {
        flex: 1,
    },

    rotulo: {
        fontSize: Fontes.medio1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        textAlign: 'center',
    },

    rotuloRoxo: {
        fontSize: Fontes.medio1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        textAlign: 'left',
    },

    descricao: {
        fontSize: Fontes.pequeno,
        fontFamily: Fontes.baseRegular,
        color: Cores.subtitulo,
        textAlign: 'center',
    },

    subTituloInfo: {
        fontSize: Fontes.pequeno,
        color: Cores.subtitulo,
        marginTop: 2,
        marginBottom: 6,
        textAlign: 'left',
    },

    lerMais: {
        fontSize: Fontes.pequeno,
        fontFamily: Fontes.baseBold,
        color: Cores.primariaEscura,
    },

    imagem: {
        width: 140,
        height: 160,
    },

    lista: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginTop: 20,
        gap: 14,
    },

    secao1: {
        backgroundColor: Cores.primariaClara,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 20,
        gap: 10,
    },

    secao2: {
        backgroundColor: Cores.secundariaClara,
        flexDirection: 'column',
        padding: 20,
        gap: 4,
    },

    secao3: {
        padding: 20,
        backgroundColor: Cores.fundo,
    },

    cabecalhoSecao: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },

    verTodos: {
        fontSize: Fontes.pequeno,
        fontFamily: Fontes.baseBold,
        color: Cores.primariaEscura,
    },

    icone: {
        width:25,
        height: 25,
    },
    iconeRoxo: {
        width:30,
        height: 30,
    },
})