import { Text, StyleSheet, TextInput, Pressable, Alert, Image, View } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Cabecalho } from '@/components/Cabecalho'
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'
import { router } from 'expo-router'

export default function ChatConversa() {

    return (
        <SafeAreaView style={estilos.conteinerGlobal}>
            <Cabecalho />
            <View style={estilos.conteiner}>
                <Pressable
                    onPress={() => router.push('/home')}>
                    <Text style={estilos.subTitulo}>‹ Voltar</Text>
                </Pressable>
                <Text style={estilos.titulo}>Chat de conversa</Text>
                <Text style={estilos.subTitulo}>Converse com alguém de forma segura, acolhedora e confidencial.</Text>
                <View style={estilos.coluna}>
                    
                    <View style={estilos.campo}>
                        <Image
                            style={estilos.icone}
                            source={require('@/assets/icones/fone.png')}
                        />
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Aqui você será ouvida</Text>
                            <Text style={estilos.texto}>Nossas conversas são sigilosas e realizadas por profissionais capacitadas para te apoiar.</Text>
                        </View>
                    </View>
                </View>


                <Text style={estilos.tituloCampo}>Com quem você deseja conversar?</Text>

                <View style={estilos.coluna}>
                    <Pressable style={estilos.campo}>
                        <View style={estilos.conteinerIconeRosa}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/usuario.png')}
                            />
                        </View>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Atendimento psicológico</Text>
                            <Text style={estilos.texto}>Converse com psicólogas especializadas em violência contra mulher.</Text>
                        </View>
                    </Pressable>

                    <Pressable style={estilos.campo}>
                        <View style={estilos.conteinerIconeRoxo}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/balanca.png')}
                            />
                        </View>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Orientação jurídica</Text>
                            <Text style={estilos.texto}>Tire duvidas sobre seus direitos e medidas protetivas.</Text>
                        </View>
                    </Pressable>


                    <Pressable style={estilos.campo}>
                        <View style={estilos.conteinerIconeRosa}>
                            <Image
                                style={estilos.icone}
                                source={require('@/assets/icones/pessoas.png')}
                            />
                        </View>
                        <View style={estilos.conteinerTexto}>
                            <Text style={estilos.tituloCampo}>Chat popular</Text>
                            <Text style={estilos.texto}>Converse com outras usuárias e compartilhe seus sentimentos e aprendizados.</Text>
                        </View>
                    </Pressable>
                </View>
            </View>
        </SafeAreaView>
    )
}

const estilos = StyleSheet.create({

    conteinerGlobal: {
        flex: 1,
        backgroundColor: Cores.primariaClara,
    },

    conteiner: {
        padding: 20,
        flexDirection: 'column',
    },


    conteinerIconeRosa: {
        width: 44,
        height: 44,
        backgroundColor: Cores.primariaClara,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
    },

    conteinerIconeRoxo: {
        width: 44,
        height: 44,
        backgroundColor: Cores.secundariaClara,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
    },

    conteinerTexto: {
        flex: 1,
    },
    coluna: {
        alignItems: 'center',
    },

    titulo: {
        fontSize: Fontes.grande1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        paddingVertical: 6,
        lineHeight: Fontes.grande1 * 1.2,
    },
    tituloCampo: {
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
    },
    subTitulo: {
        flex: 1,
        fontSize: Fontes.medio2,
        color: Cores.subtitulo,
    },

    texto: {
        flex: 1,
        fontSize: Fontes.medio1,
        color: Cores.subtitulo,
    },
    rotulo: {
        fontSize: Fontes.medio1,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        textAlign: 'center',
    },

    lerMais: {
        fontSize: Fontes.pequeno,
        fontFamily: Fontes.baseBold,
        color: Cores.primariaEscura,
    },

    imagem: {
        width: 300,
        height: 300,
    },

    icone: {
        width: 30,
        height: 30,
    },
    campo: {
        padding: 10,
        gap: 10,
        width: 350,
        minHeight: 80,
        borderRadius: 15,
        marginBottom: 10,
        borderWidth: 1,
        flexDirection: 'row',
        alignItems: 'center',
        fontSize: Fontes.pequeno,
        borderColor: Cores.primaria,
        backgroundColor: Cores.fundo,
    },
})
