import { useState } from 'react'
import { router, Link, Color } from 'expo-router'
import { ScrollView,Text, StyleSheet, TextInput, Pressable, Alert, Image, View } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'
import { useAutenticacao } from '@/hooks/useAutenticacao'

export default function NovoUsuario() {

    const [usuario, setUsuario] = useState<UsuarioTipo>(
        {codigo: '', nome: '', email: '', senha: '', dataNasc: ''}
    )

    // Cria o objeto de autenticação
    const autenticacao = useAutenticacao()

    const salvar = async () => {

        if (!usuario.email || !usuario.senha) {
            Alert.alert(
                "Erro no Cadastro", 
                "Por favor, preencha os campos de e-mail e senha."
            )
            return
        }

        // Cria a autenticação do usuário (Authentication)
        let retorno = await autenticacao.criarAutenticacaoUsuario(usuario.email, usuario.senha)

        if (retorno == 'sucesso') {

            Alert.alert(
                'Novo usuário',
                `Seja bem-vindo ${usuario.nome}!`,
                [
                    {
                        text: 'Ok',
                        onPress: () => router.push('/')
                    },
                ]
            );

        }else {

            Alert.alert(
                'Novo usuário',
                retorno,
                [{ text: 'OK' }],
                { cancelable: false } // Impede fechar tocando fora (Apenas Android)
            )
        }

    }

    const entrar = () => {
        router.push('/')
    }    

    return (
            <ScrollView>
        <SafeAreaView style={estilos.conteiner}>
            <View style={estilos.aDireita}>
                <View>
                <Text style={estilos.subTitulo}>
                    Já tem uma conta uma conta?
                    </Text>
                    <Pressable
                        onPress={entrar}
                        ><Text style={estilos.link}>Entrar </Text>
                    </Pressable>
                        </View>
            </View>

            <Text style={estilos.titulo}>Criar conta
            </Text>
            <Text style={estilos.subTitulo}>Preencha seus dados para se cadastrar
            </Text>
            <View>
                <Text style={estilos.tituloCampo}>Nome completo</Text>
                <View style={estilos.campo}>
                    <Image
                        style={estilos.icones}
                        source={require('@/assets/icones/usuario.png')}
                    />
                    <TextInput
                        style={{ width: 300 }}
                        placeholder='Digite seu nome completo'
                        placeholderTextColor={Cores.subtitulo}
                        value={usuario.nome}
                        onChangeText={(valor) => setUsuario({...usuario, nome: valor})}
                    >
                    </TextInput>
                </View>
            </View>

            <View>
                <Text style={estilos.tituloCampo}>E-mail</Text>
                <View style={estilos.campo}>
                    <Image
                        style={estilos.icones}
                        source={require('@/assets/icones/envelope.png')}
                    />
                    <TextInput
                        style={{ width: 300 }}
                        placeholder='Digite seu melhor e-mail'
                        placeholderTextColor={Cores.subtitulo}
                        value={usuario.email}
                        onChangeText={(valor) => setUsuario({...usuario, email: valor})}
                    >
                    </TextInput>
                </View>
            </View>

            <View>
                <Text style={estilos.tituloCampo}>Senha</Text>
                <View style={estilos.campo}>
                    <Image
                        style={estilos.icones}
                        source={require('@/assets/icones/trancar.png')}
                    />
                    <TextInput
                        style={{ width: 300 }}
                        placeholder='Crie uma senha segura'
                        placeholderTextColor={Cores.subtitulo}
                        value={usuario.senha}
                        onChangeText={(valor) => setUsuario({...usuario, senha: valor})}
                    >
                    </TextInput>
                </View>
            </View>

            <View>
                <Text style={estilos.tituloCampo}>Confirmar senha</Text>
                <View style={estilos.campo}>
                    <Image
                        style={estilos.icones}
                        source={require('@/assets/icones/trancar.png')}
                    />
                    <TextInput
                        style={{ width: 300 }}
                        placeholder='Confirme sua senha'
                        placeholderTextColor={Cores.subtitulo}
                        locale='pt-BR'
                        mode='single'
                        date={usuario.dataNasc}
                        validRange={{ endDate: new Date() }} // Impede a seleção de datas futuras (opcional)
                    >
                    </TextInput>
                </View>
            </View>

            <View>
                <Text style={estilos.tituloCampo}>Data de nascimento</Text>
                <View style={estilos.campo}>
                    <Image
                        style={estilos.icones}
                        source={require('@/assets/icones/calendario.png')}
                    />
                    <TextInput
                        style={{ width: 300 }}
                        placeholder='dd/mm/aaaa'
                        placeholderTextColor={Cores.subtitulo}
                    >
                    </TextInput>
                </View>
            </View>

            <View style={estilos.seguranca}>
                <View style={estilos.imagemConteiner}>
                    <Image
                        style={estilos.imagem}
                        source={require('@/assets/icones/escudo.png')}
                    />
                </View>
                <View style={estilos.textoConteiner}>
                    <Text style={estilos.tituloCampo}>Sua segurança é nossa prioridade</Text>
                    <Text style={estilos.subTitulo}>Seus dados são protegidos e nunca serão compartilhados.</Text>
                </View>
            </View>
            <Pressable
                style={estilos.botao}
                onPress={salvar}>
                <Text style={estilos.rotulo}>
                    Cadastrar
                </Text>
            </Pressable>

            <Pressable style={estilos.campo}>
                <Image
                    style={estilos.icones}
                    source={require('@/assets/icones/google.png')}
                />
                <Text style={estilos.subTitulo}>Continuar com o Google</Text>
            </Pressable>

            <Pressable style={estilos.campo}>
                <Image
                    style={estilos.icones}
                    source={require('@/assets/icones/facebook.png')}
                />
                <Text style={estilos.subTitulo}>Continuar com o Facebook</Text>
            </Pressable>

        </SafeAreaView>
                </ScrollView>
    )
}

const estilos = StyleSheet.create({
    conteiner: {
        padding: 60,
        flex: 1,
        flexDirection: 'column',
        backgroundColor: Cores.fundo,
        alignItems: 'center',
    },

    aDireita: {
        display: 'flex',
        flexDirection: 'row',
        marginLeft: 'auto',
        fontFamily: Fontes.baseRegular,
    },

    titulo: {
        fontSize: Fontes.extraGrande,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        padding: 10,
        transform: [{ scaleY: 1.2 }],
    },

    subTitulo: {
        fontSize: Fontes.medio1,
        color: Cores.subtitulo,
    },

    tituloCampo: {
        fontSize: Fontes.medio1,
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
    },

    campo: {
        width: 350,
        padding: 10,
        borderRadius: 15,
        gap: 5,
        marginBottom: 10,
        marginTop: 5,
        borderWidth: 2,
        display: 'flex',
        flexDirection: 'row',
        fontSize: Fontes.pequeno,
        borderColor: Cores.primariaClara,
        backgroundColor: Cores.fundo,
    },

    rotulo: {
        fontFamily: Fontes.baseBold,
        fontSize: Fontes.medio2,
        color: Cores.fundo
    },

    botao: {
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Cores.primariaEscura,
        fontFamily: Fontes.baseBold,
        color: Cores.fundo,
        width: 350,
        height: 40,
        borderRadius: 15,
    },

    mensagem: {
        color: Cores.erro,
        marginBottom: 10,
        fontSize: Fontes.pequeno,
        fontWeight: '500',
        padding: 5,
        borderRadius: 5,
        textAlign: 'center',
    },

    link: {
        fontFamily: Fontes.baseBold,
        fontSize: Fontes.medio1,
        color: Cores.primariaEscura,
        textDecorationLine: 'underline',
        marginLeft: 5,
    },


    icones: {
        width: 20,
        height: 20,
    },
    imagem: {
        width: 75,
        height: 75,
    },
    imagemConteiner: {
        marginRight: 10,
    },
    textoConteiner: {
        flex: 1,
    },
    seguranca: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Cores.primariaClara,
        color: Cores.subtitulo,
        margin: 15,
        padding: 10,
        width: 350,
        minHeight: 100,
        borderRadius: 5,
        borderWidth: 2,
        borderColor: Cores.secundariaClara,
    },
})