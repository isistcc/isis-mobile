import { useState } from 'react'
import { router, Link, Color } from 'expo-router'
import { Text, StyleSheet, TextInput, Pressable, Alert, Image, View } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { UsuarioTipo } from '@/types/Usuario'
import { useAutenticacao } from '@/hooks/useAutenticacao'
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'

export default function index() {

  const [usuario, setUsuario] = useState<UsuarioTipo>(
    {codigo: '', nome: '', email: '', senha: '', dataNasc: ''}
  )

  const {validarUsuario, logarContexto} = useAutenticacao()

    const verificarUsuario = async () => {

        if (!usuario.email || !usuario.senha) {
            Alert.alert(
                "Campos obrigatórios", 
                "Por favor, informe um e-mail e senha."
            )
            return
        }

        // Cria a autenticação do usuário (Authentication)
        let retorno = await validarUsuario(usuario.email, usuario.senha)

        if (retorno == 'sucesso') {

          // Salva usuário logado
          await logarContexto(usuario)

          router.push('/(auth)/home')

        }else {

            Alert.alert(
                'Falha de autenticação',
                retorno,
                [{ text: 'OK' }],
                { cancelable: false } // Impede fechar tocando fora (Apenas Android)
            )
        }
  }

  const abrirNovoUsuario = () => {
      router.push('/novoUsuario')
  }
  
    return (
        <SafeAreaView style={estilos.conteiner}>
            <View style={estilos.aDireita}>
                <Text style={estilos.subTitulo}>Ainda não possui uma conta? </Text>
                    <Pressable
                     style={estilos.link}
                        onPress={abrirNovoUsuario}
                    >
                        <Text style={estilos.link}>Cadastrar </Text>
                    </Pressable>
            </View>

            <Text style={estilos.titulo}>Login
            </Text>
            <Text style={estilos.subTitulo}>Preencha seus dados para entrar
            </Text>
            <View>
                <Text style={estilos.tituloCampo}>E-mail</Text>
                <View style={estilos.campo}>
                    <Image
                        style={estilos.icones}
                        source={require('@/assets/icones/envelope.png')}
                    />
                    <TextInput
                        placeholder='Digite seu melhor e-mail'
                        placeholderTextColor={Cores.subtitulo}
                        value={usuario.email}
                        onChangeText={(valor) => setUsuario({...usuario, email: valor})}
                    />
                </View>
            </View>

            <View>
                <Text style={estilos.tituloCampo}>Senha</Text>
                <View style={estilos.campo}>
                    <Image
                        style={estilos.icones}
                        source={require('@/assets/icones/trancar.png')}
                    />
                    <TextInput
                        placeholder='Crie uma senha segura'
                        placeholderTextColor={Cores.subtitulo}
                        value={usuario.senha}
                        onChangeText={(valor) => setUsuario({...usuario, senha: valor})}
                    />
                </View>
            </View>
            <View style={estilos.aDireita}>
                <Text style={estilos.linkCinza}>
                    Esqueci minha senha
                </Text>
            </View>

            <Pressable
                style={estilos.botao}
                onPress={verificarUsuario}
        >
                <Text style={estilos.rotulo}>
                    Entrar
                </Text>
            </Pressable>

            <Pressable style={estilos.campo}>
                    <Image
                        style={estilos.icones}
                        source={require('@/assets/icones/google.png')}
                    />
                    <Text style={estilos.subTitulo}>Continuar com o Google</Text>
                </Pressable>

            <Pressable style={estilos.campo}>
                    <Image
                        style={estilos.icones}
                        source={require('@/assets/icones/facebook.png')}
                    />
                    <Text style={estilos.subTitulo}>Continuar com o Facebook</Text>
                </Pressable>
        </SafeAreaView>
    )
}

const estilos = StyleSheet.create({
    conteiner: {
        padding: 60,
        flex: 1,
        flexDirection: 'column',
        backgroundColor: Cores.fundo,
        alignItems: 'center',
    },

    aDireita: {
        display: 'flex',
        flexDirection: 'row',
        marginLeft: 'auto',
        fontFamily: Fontes.baseRegular,
    },

    titulo: {
        fontSize: Fontes.extraGrande,
        fontFamily: Fontes.baseBold,
        color: Cores.secundariaEscura,
        padding: 10,
        transform: [{ scaleY: 1.2 }],
    },

    subTitulo: {
        fontSize: Fontes.medio1,
        color: Cores.subtitulo,
    },

    tituloCampo: {
        fontSize: Fontes.medio1,
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
    },


    campo: {
        width: 350,
        padding: 10,
        borderRadius: 15,
        gap: 5,
        marginBottom: 10,
        marginTop: 5,
        borderWidth: 2,
        display: 'flex',
        flexDirection: 'row',
        fontSize: Fontes.pequeno,
        borderColor: Cores.primariaClara,
        backgroundColor: Cores.fundo,
    },

    rotulo: {
        fontFamily: Fontes.baseBold,
        fontSize: Fontes.medio2,
        color: Cores.fundo
    },

    botao: {
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Cores.primariaEscura,
        fontFamily: Fontes.baseBold,
        color: Cores.fundo,
        width: 350,
        height: 40,
        borderRadius: 15,
        marginTop: 100,
        marginBottom: 50,
    },

    mensagem: {
        color: Cores.erro,
        marginBottom: 10,
        fontSize: Fontes.pequeno,
        fontWeight: '500',
        padding: 5,
        borderRadius: 5,
        textAlign: 'center',
    },

    link: {
        fontFamily: Fontes.baseBold,
        fontSize: Fontes.medio1,
        color: Cores.primariaEscura,
        textDecorationLine: 'underline',
        marginLeft: 5,
    },

    linkCinza: {
        fontFamily: Fontes.baseRegular,
        fontSize: Fontes.medio1,
        color: Cores.subtitulo,
        textDecorationLine: 'underline',
        padding: 5,
    },

    icones: {
        width: 20,
        height: 20,
    },
})