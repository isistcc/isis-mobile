export const Fontes = {
    baseLight: 'PoppinsLight',
    baseRegular: 'PoppinsRegular',
    baseBold: 'PoppinsBold',
    logo: 'CormorantGaramondRegular',
    pequeno: 8,
    medio1: 12,
    medio2: 16,
    grande1: 20,
    grande2: 24,
    extraGrande: 32,
}