export const Cores = {
    primariaClara: '#FDEEF5',
    primaria: '#F59DC2',
    primariaEscura: '#E04B95',
    secundariaClara: '#EEDDF0',
    secundaria: '#B77FCD',
    secundariaEscura: '#422064',
    erro: '#d90429',
    fundo: '#ffffff',
    subtitulo: '#5c5c5c',
}