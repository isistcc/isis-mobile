
type RegistroTipo = {
    id: string
    texto: string
    data: Date
    humor: string | null
}