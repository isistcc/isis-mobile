export type UsuarioTipo = {
    codigo: string
    nome: string
    email: string
    senha: string
    dataNasc: Date
}