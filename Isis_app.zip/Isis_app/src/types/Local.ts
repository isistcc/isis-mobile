export type TipoLocal = 'hospitais' | 'delegacias' | 'advogados'
 
export type LocalTipo = {
    id: string
    nome: string
    tipo: TipoLocal
    lat: number
    lng: number
}
 
export type FiltrosState = {
    hospitais: boolean
    delegacias: boolean
    advogados: boolean
}
 
