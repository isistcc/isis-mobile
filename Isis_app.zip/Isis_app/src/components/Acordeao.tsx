import { ReactNode } from 'react';
import { Cores } from '@/constants/Cores'
import { Fontes } from '@/constants/Fontes'
import { View, Text, TouchableOpacity, StyleSheet, Pressable } from 'react-native';

type AcordeaoProps = {
    id: string
    titulo: string
    aberto: boolean;
    onToggle: (id: string) => void;
    children: ReactNode;
}

export function Acordeao({ id, titulo, aberto, onToggle, children }: AcordeaoProps) {
    return (
        <View style={estilos.conteiner}>
            <Pressable
                style={[estilos.cabecalho]}
                onPress={() => onToggle(id)}
            >
                
                    <Text style={estilos.tituloCampo}>{titulo}</Text>
                    <Text style={estilos.seta}>{aberto ? '▲' : '▼'}</Text>
            </Pressable>

            {aberto && (
                <View style={estilos.conteudo}>
                    {children}
                </View>
            )}
        </View>
    )
}
const estilos = StyleSheet.create({

    conteiner: {
        width: 350,
        padding: 10,
        borderRadius: 15,
        gap: 5,
        marginBottom: 10,
        marginTop: 5,
        borderWidth: 2,
        display: 'flex',
        fontSize: Fontes.pequeno,
        borderColor: Cores.secundariaClara,
        backgroundColor: Cores.fundo,
    },
    cabecalho: {
        fontSize: Fontes.medio1,
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
        flexDirection: 'row',
        gap: 5,
    },
    tituloCampo: {
        fontSize: Fontes.medio1,
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
    },
    seta: {
        fontSize: Fontes.medio1,
        color: Cores.secundariaEscura,
        fontFamily: Fontes.baseBold,
        marginLeft: 'auto',
    },
    conteudo: {
        padding: 10,
        gap: 5,
        display: 'flex',
    }
}
)
