import { StyleSheet, Text, View, Pressable, Alert, Image } from 'react-native'
import { router, Link, useUnstableGlobalHref } from 'expo-router'
import { Fontes } from '@/constants/Fontes'
import { Cores } from '@/constants/Cores'
import { useAutenticacao } from '@/hooks/useAutenticacao'
import { UsuarioTipo } from '@/types/Usuario'

export function Cabecalho() {
    const voltar = () => {
        router.replace('/home')
    }

    const abrirSobre = () => {
        router.push('/(auth)/(pilha)/sobre')
    }

    
    const abrirPerfil = () => {
        router.push('/(auth)/(pilha)/perfil')
    }

    return (
        <View style={estilos.conteiner}>
            <Pressable
                onPress={voltar}>
                <Image
                    style={estilos.logo}
                    source={require('@/assets/images/logo.png')}
                />
            </Pressable>

            <View style={estilos.aDireita}>
                <Pressable
                    onPress={abrirSobre}>
                    <Text style={estilos.subTitulo}>
                        Sobre
                    </Text>
                </Pressable>


                <Pressable
                    onPress={abrirPerfil}>
                    <Text style={estilos.rotulo}>
                        Olá, 
                    </Text>
                </Pressable>

            </View>
        </View>

    )
}

const estilos = StyleSheet.create({
    conteiner: {
        flexDirection: 'row',
        backgroundColor: Cores.fundo,
        alignItems: 'center',
        padding: 8,
        minHeight: 55,
    },

    logo: {
        width: 150,
        height: 50,
        margin: 10,
    },

aDireita: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginLeft: 'auto',
    gap: 10,
},

    icone: {
        width: 12,
        height: 12,
    },
    campo: {
        width: 80,
        height: 20,
        padding: 10,
        gap: 10,
        flexDirection: 'row',
        alignItems: 'center',
        borderRadius: 10,
        borderWidth: 1,
        borderColor: Cores.primariaEscura,
        backgroundColor: Cores.fundo,
    },
    rotulo: {
        color: Cores.primariaEscura,
        fontSize: Fontes.pequeno,
        fontFamily: Fontes.baseBold,
        borderColor: Cores.primariaEscura,
        backgroundColor: Cores.fundo,
    },
    subTitulo: {
        fontSize: Fontes.pequeno,
        color: Cores.subtitulo,
    }
})